<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('games', function (Blueprint $table) {
        $table->id();
        $table->string('nama_game');
        $table->string('genre');
        $table->string('platform');
        $table->string('developer');
        $table->decimal('rating', 3, 1);
        $table->foreignId('category_id')
            ->constrained('categories')
            ->onDelete('cascade');


        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('games');
    }
};
