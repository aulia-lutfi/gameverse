<?php

namespace App\Http\Controllers;

use App\Models\Game;
use Illuminate\Http\Request;

class GameController extends Controller
{
    // Tampilkan semua data game
    public function index()
    {
        $games = Game::all();
        return view('games.index', compact('games'));
    }

    // Simpan data game baru ke database
    public function store(Request $request)
    {
        $request->validate([
            'nama_game' => 'required',
            'genre'     => 'required',
            'platform'  => 'required',
            'developer' => 'required',
            'rating'    => 'required|numeric|min:0|max:10',
        ]);

        Game::create($request->all());

        return redirect('/')->with('success', 'Game berhasil ditambahkan!');
    }

    // Hapus data game dari database
    public function destroy($id)
    {
        Game::findOrFail($id)->delete();

        return redirect('/')->with('success', 'Game berhasil dihapus!');
    }
}