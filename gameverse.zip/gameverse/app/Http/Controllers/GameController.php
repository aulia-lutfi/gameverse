<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\Category;
use Illuminate\Http\Request;

class GameController extends Controller
{
    // tampil data
    public function index()
    {
        $games = Game::with('category')->get();
        $categories = Category::all();

        return view('games.index', compact('games', 'categories'));
    }

    // tambah data
    public function store(Request $request)
    {
        Game::create([
            'nama_game' => $request->nama_game,
            'genre' => $request->genre,
            'platform' => $request->platform,
            'developer' => $request->developer,
            'rating' => $request->rating,
            'category_id' => $request->category_id,
        ]);

        return redirect('/');
    }

    // form edit
    public function edit($id)
    {
        $game = Game::find($id);
        $categories = Category::all();

        return view('games.edit', compact('game', 'categories'));
    }

    // update data
    public function update(Request $request, $id)
    {
        $game = Game::find($id);

        $game->update([
            'nama_game' => $request->nama_game,
            'genre' => $request->genre,
            'platform' => $request->platform,
            'developer' => $request->developer,
            'rating' => $request->rating,
            'category_id' => $request->category_id,
        ]);

        return redirect('/');
    }

    // search menggunakan where()
    public function search(Request $request)
    {
        $games = Game::where(
            'nama_game',
            'like',
            '%' . $request->keyword . '%'
        )->with('category')->get();

        $categories = Category::all();

        return view('games.index', compact('games', 'categories'));
    }

    // hapus data
    public function destroy($id)
    {
        $game = Game::find($id);
        $game->delete();

        return redirect('/');
    }
}