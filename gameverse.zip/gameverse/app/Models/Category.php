<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = [
        'nama_kategori'
    ];

    // Relasi: satu category punya banyak game
    public function games()
    {
        return $this->hasMany(Game::class);
    }
}