@extends('layout')

@section('content')

<div class="card-custom">

    <h2 class="title-page mb-4">
        Edit Data Game
    </h2>

    <form>

        <div class="mb-3">
            <label>Nama Game</label>
            <input type="text" class="form-control" value="Valorant">
        </div>

        <div class="mb-3">
            <label>Genre</label>
            <input type="text" class="form-control" value="FPS">
        </div>

        <div class="mb-3">
            <label>Platform</label>
            <input type="text" class="form-control" value="PC">
        </div>

        <div class="mb-3">
            <label>Developer</label>
            <input type="text" class="form-control" value="Riot Games">
        </div>

        <div class="mb-3">
            <label>Rating</label>
            <input type="number" class="form-control" value="9">
        </div>

        <button class="btn btn-warning">
            Update
        </button>

    </form>

</div>

@endsection