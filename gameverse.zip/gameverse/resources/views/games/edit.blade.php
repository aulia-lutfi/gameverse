@extends('layout')

@section('content')

<div class="card-custom">

    <h2 class="title-page mb-4">
        Edit Data Game
    </h2>

    <form action="/update/{{ $game->id }}" method="POST">

        @csrf
        @method('PUT')

        {{-- NAMA GAME --}}
        <div class="mb-3">
            <label>Nama Game</label>

            <input type="text"
                   name="nama_game"
                   class="form-control"
                   value="{{ $game->nama_game }}">
        </div>

        {{-- GENRE --}}
        <div class="mb-3">
            <label>Genre</label>

            <select name="genre" class="form-control">

                <option value="FPS"
                    {{ $game->genre == 'FPS' ? 'selected' : '' }}>
                    FPS
                </option>

                <option value="RPG"
                    {{ $game->genre == 'RPG' ? 'selected' : '' }}>
                    RPG
                </option>

                <option value="Action"
                    {{ $game->genre == 'Action' ? 'selected' : '' }}>
                    Action
                </option>

                <option value="Adventure"
                    {{ $game->genre == 'Adventure' ? 'selected' : '' }}>
                    Adventure
                </option>

                <option value="Sports"
                    {{ $game->genre == 'Sports' ? 'selected' : '' }}>
                    Sports
                </option>

            </select>
        </div>

        {{-- PLATFORM --}}
        <div class="mb-3">
            <label>Platform</label>

            <input type="text"
                   name="platform"
                   class="form-control"
                   value="{{ $game->platform }}">
        </div>

        {{-- DEVELOPER --}}
        <div class="mb-3">
            <label>Developer</label>

            <input type="text"
                   name="developer"
                   class="form-control"
                   value="{{ $game->developer }}">
        </div>

        {{-- RATING --}}
        <div class="mb-3">
            <label>Rating</label>

            <input type="number"
                   step="0.1"
                   name="rating"
                   class="form-control"
                   value="{{ $game->rating }}">
        </div>

        {{-- CATEGORY --}}
        <div class="mb-3">
            <label>Category</label>

            <select name="category_id" class="form-control">

                @foreach($categories as $category)

                    <option value="{{ $category->id }}"
                        {{ $game->category_id == $category->id ? 'selected' : '' }}>

                        {{ $category->nama_kategori }}

                    </option>

                @endforeach

            </select>
        </div>

        {{-- BUTTON --}}
        <button class="btn btn-warning">
            Update
        </button>

    </form>

</div>

@endsection