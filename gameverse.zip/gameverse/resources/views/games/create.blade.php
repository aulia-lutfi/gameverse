@extends('layout')

@section('content')

<div class="card-custom">

    <h2 class="title-page mb-4">
        Tambah Data Game
    </h2>

    <form>

        <div class="mb-3">
            <label>Nama Game</label>
            <input type="text" class="form-control">
        </div>

        <div class="mb-3">
            <label>Genre</label>
            <input type="text" class="form-control">
        </div>

        <div class="mb-3">
            <label>Platform</label>
            <input type="text" class="form-control">
        </div>

        <div class="mb-3">
            <label>Developer</label>
            <input type="text" class="form-control">
        </div>

        <div class="mb-3">
            <label>Rating</label>
            <input type="number" class="form-control">
        </div>

        <button class="btn btn-primary">
            Simpan
        </button>

    </form>

</div>

@endsection