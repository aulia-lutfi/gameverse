@extends('layout')

@section('content')

{{-- FLASH MESSAGE --}}
@if(session('success'))
<div style="background:rgba(52,211,153,.15);border:1px solid rgba(52,211,153,.3);
            color:#6ee7b7;padding:10px 16px;border-radius:10px;margin-bottom:16px;font-size:13px;">
    ✓ {{ session('success') }}
</div>
@endif

{{-- HERO STRIP --}}
<div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;flex-wrap:wrap;">
    <div>
        <h1 style="font-family:'Rajdhani',sans-serif;font-size:32px;font-weight:700;color:#fff;line-height:1;margin:0;">
            Data Game <span style="color:#00e5ff;">Populer</span>
        </h1>
        <p style="font-size:12px;color:#6b7280;margin-top:6px;margin-bottom:0;">
            Daftar game populer modern 2026
        </p>
    </div>
    <div style="display:flex;gap:10px;margin-left:auto;">
        <div style="background:#161b28;border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:10px 20px;text-align:center;">
            <div style="font-family:'Rajdhani',sans-serif;font-size:24px;font-weight:700;color:#00e5ff;">{{ count($games) }}</div>
            <div style="font-size:10px;color:#6b7280;margin-top:2px;">Total Game</div>
        </div>
        <div style="background:#161b28;border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:10px 20px;text-align:center;">
            <div style="font-family:'Rajdhani',sans-serif;font-size:24px;font-weight:700;color:#fcd34d;">
                {{ $games->count() ? number_format($games->max('rating'),1) : '0' }}
            </div>
            <div style="font-size:10px;color:#6b7280;margin-top:2px;">Rating Tertinggi</div>
        </div>
    </div>
</div>

{{-- FORM TAMBAH GAME --}}
<div style="background:#111520;border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:18px 20px;margin-bottom:20px;">
    <div style="font-size:13px;color:#00e5ff;margin-bottom:14px;font-weight:500;">+ Tambah Game Baru</div>
    <form action="/games" method="POST">
        @csrf
        <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 0.7fr 1fr;gap:10px;align-items:center;">

            <input type="text" name="nama_game"
                style="background:#161b28;border:1px solid rgba(255,255,255,0.1);border-radius:8px;
                       padding:8px 12px;color:#e8eaf0;font-size:13px;outline:none;width:100%;"
                placeholder="Nama Game" required>

            <select name="genre"
                style="background:#161b28;border:1px solid rgba(255,255,255,0.1);border-radius:8px;
                       padding:8px 12px;color:#e8eaf0;font-size:13px;outline:none;width:100%;">
                <option value="FPS">FPS</option>
                <option value="RPG">RPG</option>
                <option value="Sports">Sports</option>
                <option value="Sandbox">Sandbox</option>
                <option value="Action">Action</option>
                <option value="Adventure">Adventure</option>
            </select>

            <input type="text" name="platform"
                style="background:#161b28;border:1px solid rgba(255,255,255,0.1);border-radius:8px;
                       padding:8px 12px;color:#e8eaf0;font-size:13px;outline:none;width:100%;"
                placeholder="Platform" required>

            <input type="text" name="developer"
                style="background:#161b28;border:1px solid rgba(255,255,255,0.1);border-radius:8px;
                       padding:8px 12px;color:#e8eaf0;font-size:13px;outline:none;width:100%;"
                placeholder="Developer" required>

            <input type="number" name="rating" step="0.1" min="0" max="10"
                style="background:#161b28;border:1px solid rgba(255,255,255,0.1);border-radius:8px;
                       padding:8px 12px;color:#e8eaf0;font-size:13px;outline:none;width:100%;"
                placeholder="Rating" required>

            <button type="submit"
                style="background:#00e5ff;color:#0a0d14;border:none;border-radius:8px;
                       padding:9px 16px;font-size:13px;font-weight:600;cursor:pointer;width:100%;">
                + Simpan
            </button>
        </div>
    </form>
</div>

{{-- TABEL DATA GAME --}}
<div style="background:#111520;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden;">
    <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;">

            <thead>
                <tr style="border-bottom:1px solid rgba(255,255,255,0.07);">
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">No</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Game</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Genre</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Platform</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Developer</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Rating</th>
                    <th style="text-align:left;font-size:10px;font-weight:500;color:#6b7280;padding:12px 18px;text-transform:uppercase;letter-spacing:.06em;white-space:nowrap;">Aksi</th>
                </tr>
            </thead>

            <tbody>
                @forelse($games as $game)
                <tr style="border-bottom:1px solid rgba(255,255,255,0.04);">

                    {{-- NO --}}
                    <td style="padding:14px 18px;color:#6b7280;font-size:11px;white-space:nowrap;">
                        #{{ $game->id }}
                    </td>

                    {{-- NAMA GAME --}}
                    <td style="padding:14px 18px;white-space:nowrap;">
                        <div style="display:flex;align-items:center;gap:12px;">
                            <div style="width:38px;height:38px;border-radius:8px;background:rgba(255,255,255,0.04);
                                        border:1px solid rgba(255,255,255,0.07);display:flex;align-items:center;
                                        justify-content:center;font-size:18px;flex-shrink:0;">🎮</div>
                            <div>
                                <div style="font-weight:500;font-size:13px;color:#e8eaf0;line-height:1.3;">{{ $game->nama_game }}</div>
                                <div style="font-size:11px;color:#6b7280;margin-top:2px;">{{ $game->developer }}</div>
                            </div>
                        </div>
                    </td>

                    {{-- GENRE --}}
                    <td style="padding:14px 18px;white-space:nowrap;">
                        @php
                            $badgeStyle = [
                                'FPS'       => 'background:rgba(0,229,255,.12);color:#67e8f9;border:1px solid rgba(0,229,255,.2)',
                                'RPG'       => 'background:rgba(124,58,237,.15);color:#a78bfa;border:1px solid rgba(124,58,237,.2)',
                                'Sports'    => 'background:rgba(52,211,153,.12);color:#6ee7b7;border:1px solid rgba(52,211,153,.2)',
                                'Sandbox'   => 'background:rgba(251,191,36,.12);color:#fcd34d;border:1px solid rgba(251,191,36,.2)',
                                'Action'    => 'background:rgba(255,77,109,.15);color:#ff6b85;border:1px solid rgba(255,77,109,.2)',
                                'Adventure' => 'background:rgba(245,101,48,.15);color:#fb923c;border:1px solid rgba(245,101,48,.2)',
                            ];
                            $bs = $badgeStyle[$game->genre] ?? 'background:rgba(255,255,255,.08);color:#e8eaf0;border:1px solid rgba(255,255,255,.1)';
                        @endphp
                        <span style="display:inline-block;font-size:11px;padding:3px 10px;border-radius:20px;font-weight:500;{{ $bs }}">
                            {{ $game->genre }}
                        </span>
                    </td>

                    {{-- PLATFORM --}}
                    <td style="padding:14px 18px;white-space:nowrap;">
                        <span style="font-size:11px;color:#6b7280;background:rgba(255,255,255,0.05);
                                     border-radius:4px;padding:3px 9px;">
                            {{ $game->platform }}
                        </span>
                    </td>

                    {{-- DEVELOPER --}}
                    <td style="padding:14px 18px;color:#6b7280;font-size:13px;white-space:nowrap;">
                        {{ $game->developer }}
                    </td>

                    {{-- RATING --}}
                    <td style="padding:14px 18px;white-space:nowrap;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:4px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;">
                                <div style="height:100%;width:{{ $game->rating * 10 }}%;border-radius:2px;
                                    background:{{ $game->rating >= 9 ? 'linear-gradient(90deg,#34d399,#06b6d4)' : ($game->rating >= 7 ? 'linear-gradient(90deg,#fbbf24,#f97316)' : 'linear-gradient(90deg,#f87171,#e11d48)') }};">
                                </div>
                            </div>
                            <span style="font-size:13px;font-weight:500;color:#e8eaf0;">{{ $game->rating }}</span>
                        </div>
                    </td>

                    {{-- AKSI --}}
                    <td style="padding:14px 18px;white-space:nowrap;">
                        <form action="/games/{{ $game->id }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                onclick="return confirm('Hapus game {{ $game->nama_game }}?')"
                                style="background:transparent;border:1px solid rgba(255,255,255,0.07);
                                       border-radius:6px;padding:6px 10px;cursor:pointer;font-size:14px;color:#6b7280;">
                                🗑️
                            </button>
                        </form>
                    </td>

                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center;padding:40px;color:#6b7280;font-size:13px;">
                        Belum ada data game. Tambahkan sekarang! 🎮
                    </td>
                </tr>
                @endforelse
            </tbody>

        </table>
    </div>

    {{-- CODE HINT STRIP --}}
    <div style="display:flex;gap:20px;flex-wrap:wrap;padding:10px 18px;
                background:rgba(0,229,255,0.03);border-top:1px solid rgba(0,229,255,0.08);">
        <span style="font-size:11px;color:#6b7280;">
            <code style="font-family:monospace;color:#00e5ff;background:rgba(0,229,255,0.08);padding:1px 5px;border-radius:3px;">Model</code>
            app/Models/Game.php
        </span>
        <span style="font-size:11px;color:#6b7280;">
            <code style="font-family:monospace;color:#00e5ff;background:rgba(0,229,255,0.08);padding:1px 5px;border-radius:3px;">Controller</code>
            GameController.php
        </span>
        <span style="font-size:11px;color:#6b7280;">
            <code style="font-family:monospace;color:#00e5ff;background:rgba(0,229,255,0.08);padding:1px 5px;border-radius:3px;">View</code>
            resources/views/index.blade.php
        </span>
        <span style="font-size:11px;color:#6b7280;">
            <code style="font-family:monospace;color:#00e5ff;background:rgba(0,229,255,0.08);padding:1px 5px;border-radius:3px;">DB</code>
            MySQL · tabel games
        </span>
    </div>
</div>

@endsection