<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GameController;

Route::get('/', [GameController::class, 'index']);

Route::post('/store', [GameController::class, 'store']);

Route::get('/edit/{id}', [GameController::class, 'edit']);

Route::put('/update/{id}', [GameController::class, 'update']);

Route::delete('/delete/{id}', [GameController::class, 'destroy']);

Route::get('/search', [GameController::class, 'search']);