<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GameController;

Route::get('/', [GameController::class, 'index']);
Route::post('/games', [GameController::class, 'store'])->name('games.store');
Route::delete('/games/{id}', [GameController::class, 'destroy'])->name('games.destroy');