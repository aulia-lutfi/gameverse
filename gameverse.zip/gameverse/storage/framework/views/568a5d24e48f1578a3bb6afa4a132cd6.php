

<?php $__env->startSection('content'); ?>

<div class="card-custom">

    <h2 class="title-page mb-4">
        Edit Data Game
    </h2>

    <form action="/update/<?php echo e($game->id); ?>" method="POST">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label>Nama Game</label>

            <input type="text"
                   name="nama_game"
                   class="form-control"
                   value="<?php echo e($game->nama_game); ?>">
        </div>

        
        <div class="mb-3">
            <label>Genre</label>

            <select name="genre" class="form-control">

                <option value="FPS"
                    <?php echo e($game->genre == 'FPS' ? 'selected' : ''); ?>>
                    FPS
                </option>

                <option value="RPG"
                    <?php echo e($game->genre == 'RPG' ? 'selected' : ''); ?>>
                    RPG
                </option>

                <option value="Action"
                    <?php echo e($game->genre == 'Action' ? 'selected' : ''); ?>>
                    Action
                </option>

                <option value="Adventure"
                    <?php echo e($game->genre == 'Adventure' ? 'selected' : ''); ?>>
                    Adventure
                </option>

                <option value="Sports"
                    <?php echo e($game->genre == 'Sports' ? 'selected' : ''); ?>>
                    Sports
                </option>

            </select>
        </div>

        
        <div class="mb-3">
            <label>Platform</label>

            <input type="text"
                   name="platform"
                   class="form-control"
                   value="<?php echo e($game->platform); ?>">
        </div>

        
        <div class="mb-3">
            <label>Developer</label>

            <input type="text"
                   name="developer"
                   class="form-control"
                   value="<?php echo e($game->developer); ?>">
        </div>

        
        <div class="mb-3">
            <label>Rating</label>

            <input type="number"
                   step="0.1"
                   name="rating"
                   class="form-control"
                   value="<?php echo e($game->rating); ?>">
        </div>

        
        <div class="mb-3">
            <label>Category</label>

            <select name="category_id" class="form-control">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($category->id); ?>"
                        <?php echo e($game->category_id == $category->id ? 'selected' : ''); ?>>

                        <?php echo e($category->nama_kategori); ?>


                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>

        
        <button class="btn btn-warning">
            Update
        </button>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gameverse\resources\views/games/edit.blade.php ENDPATH**/ ?>