

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
<div style="background:rgba(52,211,153,.15);border:1px solid rgba(52,211,153,.3);
            color:#6ee7b7;padding:10px 16px;border-radius:10px;margin-bottom:16px;font-size:13px;">
    ✓ <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
    <div>
        <h1 style="font-size:30px;color:#fff;margin:0;">
            Data Game
        </h1>
        <p style="font-size:12px;color:#6b7280;">
            Laravel Eloquent ORM
        </p>
    </div>
</div>


<div style="margin-bottom:20px;">
    <form action="/search" method="GET" style="display:flex;gap:10px;">
        <input type="text" name="keyword"
            placeholder="Cari game..."
            style="flex:1;background:#161b28;border:1px solid rgba(255,255,255,0.1);
                   border-radius:8px;padding:10px 14px;color:#fff;font-size:13px;">

        <button type="submit"
            style="background:#00e5ff;color:#000;border:none;border-radius:8px;
                   padding:10px 18px;font-weight:600;cursor:pointer;">
            Cari
        </button>
    </form>
</div>


<div style="background:#111520;border-radius:14px;padding:20px;margin-bottom:20px;">

    <form action="/store" method="POST">
        <?php echo csrf_field(); ?>

        <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:10px;">

            <input type="text" name="nama_game"
                placeholder="Nama Game"
                required
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

            <select name="genre"
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

                <option value="FPS">FPS</option>
                <option value="RPG">RPG</option>
                <option value="Action">Action</option>
                <option value="Adventure">Adventure</option>
                <option value="Sports">Sports</option>

            </select>

            <input type="text" name="platform"
                placeholder="Platform"
                required
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

            <input type="text" name="developer"
                placeholder="Developer"
                required
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

            <input type="number" step="0.1" name="rating"
                placeholder="Rating"
                required
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

            
            <select name="category_id"
                style="padding:10px;border-radius:8px;border:none;background:#161b28;color:white;">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>">
                        <?php echo e($category->nama_kategori); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </div>

        <button type="submit"
            style="margin-top:14px;background:#00e5ff;color:black;
                   border:none;padding:10px 18px;border-radius:8px;
                   font-weight:600;cursor:pointer;">
            + Tambah Game
        </button>

    </form>
</div>


<div style="background:#111520;border-radius:14px;overflow:hidden;">

    <table style="width:100%;border-collapse:collapse;">

        <thead>
            <tr style="background:#161b28;color:#6b7280;font-size:12px;">
                <th style="padding:14px;">No</th>
                <th>Nama Game</th>
                <th>Genre</th>
                <th>Platform</th>
                <th>Developer</th>
                <th>Rating</th>
                <th>Category</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr style="border-top:1px solid rgba(255,255,255,0.05);">

                <td style="padding:14px;color:white;">
                    <?php echo e($game->id); ?>

                </td>

                <td style="padding:14px;color:white;">
                    <?php echo e($game->nama_game); ?>

                </td>

                <td style="padding:14px;color:white;">
                    <?php echo e($game->genre); ?>

                </td>

                <td style="padding:14px;color:white;">
                    <?php echo e($game->platform); ?>

                </td>

                <td style="padding:14px;color:white;">
                    <?php echo e($game->developer); ?>

                </td>

                <td style="padding:14px;color:white;">
                    <?php echo e($game->rating); ?>

                </td>

                
                <td style="padding:14px;color:#00e5ff;">
                    <?php echo e($game->category->nama_kategori); ?>

                </td>

                <td style="padding:14px;">

                    
                    <a href="/edit/<?php echo e($game->id); ?>"
                        style="text-decoration:none;
                               background:#00e5ff;
                               color:black;
                               padding:6px 10px;
                               border-radius:6px;
                               font-size:12px;
                               margin-right:6px;">
                        Edit
                    </a>

                    
                    <form action="/delete/<?php echo e($game->id); ?>"
                        method="POST"
                        style="display:inline;">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                            onclick="return confirm('Hapus data?')"
                            style="background:#ef4444;
                                   color:white;
                                   border:none;
                                   padding:6px 10px;
                                   border-radius:6px;
                                   cursor:pointer;
                                   font-size:12px;">
                            Hapus
                        </button>

                    </form>

                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="8"
                    style="padding:30px;text-align:center;color:#6b7280;">
                    Belum ada data game
                </td>
            </tr>

            <?php endif; ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gameverse\resources\views/games/index.blade.php ENDPATH**/ ?>