<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameVerse</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=Inter:wght@400;500&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #0a0d14;
            --card: #111520;
            --card2: #161b28;
            --accent: #00e5ff;
            --accent2: #ff4d6d;
            --accent3: #7c3aed;
            --text: #e8eaf0;
            --muted: #6b7280;
            --border: rgba(255, 255, 255, 0.07);
            --font-display: 'Rajdhani', sans-serif;
            --font-body: 'Inter', sans-serif;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: var(--font-body);
            font-size: 13px;
            min-height: 100vh;
        }

        /* NAVBAR */
        .navbar {
            background: rgba(10, 13, 20, 0.97);
            border-bottom: 1px solid var(--border);
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(8px);
        }

        .navbar-brand {
            font-family: var(--font-display) !important;
            font-size: 24px !important;
            font-weight: 700 !important;
            letter-spacing: 1px;
            color: var(--accent) !important;
            text-shadow: 0 0 20px rgba(0, 229, 255, 0.4);
            text-decoration: none;
        }

        .navbar-brand span {
            color: var(--accent2);
        }

        .nav-link-custom {
            color: var(--muted);
            font-size: 12px;
            padding: 5px 12px;
            border-radius: 6px;
            text-decoration: none;
            transition: all .15s;
        }

        .nav-link-custom:hover,
        .nav-link-custom.active {
            color: var(--text);
            background: rgba(255, 255, 255, 0.06);
        }

        .nav-link-custom.active {
            color: var(--accent);
        }

        .user-pill {
            display: flex;
            align-items: center;
            gap: 8px;
            background: var(--card2);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 4px 12px 4px 4px;
        }

        .avatar {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent3), var(--accent));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            color: #fff;
        }

        /* MAIN CONTENT WRAPPER */
        .main-wrapper {
            max-width: 1100px;
            margin: 0 auto;
            padding: 28px 20px;
        }
    </style>
</head>

<body>

<nav class="navbar">
    <div class="container d-flex align-items-center gap-3">
        <a class="navbar-brand" href="#">Game<span>Verse</span></a>

        <div class="d-flex gap-1 flex-grow-1">
            <a href="#" class="nav-link-custom active">🎮 Data Game</a>
            <a href="#" class="nav-link-custom">🏷️ Genre</a>
            <a href="#" class="nav-link-custom">👾 Developer</a>
            <a href="#" class="nav-link-custom">📊 Statistik</a>
        </div>

        <div class="user-pill">
            <div class="avatar">A</div>
            <span style="font-size: 12px; color: var(--muted)">admin</span>
        </div>
    </div>
</nav>

<div class="main-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\gameverse\resources\views/layout.blade.php ENDPATH**/ ?>